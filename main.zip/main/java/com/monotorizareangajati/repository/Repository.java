package com.monotorizareangajati.repository;

public interface Repository {

}
