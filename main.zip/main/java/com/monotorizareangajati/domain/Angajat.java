package com.monotorizareangajati.domain;

import lombok.*;

import javax.persistence.*;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@Table(name = "angajat")

public class Angajat implements Identifiable<Integer> {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Integer id;

    @Column(name = "nume", nullable = false, unique = true)
    private String nume;

    @Column(name = "prenume", nullable = false, unique = true)
    private String prenume;

    @OneToMany(mappedBy = "angajat", fetch = FetchType.LAZY)
    private List<Task> assignedTasks;
}
