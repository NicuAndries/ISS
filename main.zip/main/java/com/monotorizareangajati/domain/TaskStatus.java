package com.monotorizareangajati.domain;

public enum TaskStatus {
    PENDING,
    DONE
}
