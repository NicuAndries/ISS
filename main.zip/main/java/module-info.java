module com.monotorizareangajati {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires org.kordamp.bootstrapfx.core;
    requires lombok;
    requires java.persistence;
    requires java.sql;

    opens com.monotorizareangajati to javafx.fxml;
    opens com.monotorizareangajati.controller to javafx.fxml;

    exports com.monotorizareangajati;
    exports com.monotorizareangajati.controller;
}